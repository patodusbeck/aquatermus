 const express = require('express');
const http = require('http');
const { SerialPort, ReadlineParser } = require('serialport');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static('public')); // HTML na pasta "public"

// Função que detecta automaticamente a porta do Arduino
async function findArduinoPort() {
  const ports = await SerialPort.list();
  const arduinoPort = ports.find(port =>
    port.manufacturer?.includes('Arduino') ||
    port.path.includes('wchusb') ||    // CH340
    port.manufacturer?.includes('wch') || // Alguns clones chineses
    port.friendlyName?.includes('USB Serial') ||
    port.vendorId === '2341' ||         // Original Arduino vendor ID
    port.vendorId === '1A86'            // CH340 vendor ID
  );

  return arduinoPort?.path;
}

async function start() {
  const arduinoPath = await findArduinoPort();

  if (!arduinoPath) {
    console.error('❌ Arduino não encontrado. Verifique a conexão USB.');
    return;
  }

  console.log(`✅ Conectando ao Arduino na porta: ${arduinoPath}`);

  const port = new SerialPort({ path: arduinoPath, baudRate: 9600 });
  const parser = port.pipe(new ReadlineParser({ delimiter: '\r\n' }));

  parser.on('data', (data) => {
    const temp = parseFloat(data);
    if (!isNaN(temp)) {
      console.log(`🌡️  Temp: ${temp} °C`);
      io.emit('temperature', temp);
    }
  });

  port.on('error', err => {
    console.error('❌ Erro na porta serial:', err.message);
  });

  server.listen(3000, () => {
    console.log('🌐 Servidor rodando em http://localhost:3000');
  });
}

start();

