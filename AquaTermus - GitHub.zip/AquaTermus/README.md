
## ✦ AquaTermus IEMA

- AquaTermus é um projeto de cunho educativo que preza conhecimentos em Arduino UNO e desenvolvimento de códigos HTML usando sensores de temperatura.
